#pragma once

#import <Foundation/Foundation.h>

#define NMF_EXPORT __attribute__((visibility ("default")))
