#import <Foundation/Foundation.h>

const static NSString *INFOWINDOW_TITLE_KEY = @"NMF_MARKER_TITLE";
