#import "NMFFoundation.h"

/**
 피킹이 가능한 지도 요소를 정의한 프로토콜.
 */
@protocol NMFPickable <NSObject>
@end
