#import "NMFFoundation.h"

/**
 클러스터러의 데이터 갱신이 완료되면 호출되는 콜백 타입.
 */
typedef void (^NMCClustererUpdateCallback)(void);
